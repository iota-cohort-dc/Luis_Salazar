$(document).ready(function(){

	$(".ninja").click(function(){
		$(this).hide('slow');
	})	

	$('.butt').click(function(){
		$('.ninja').show();
	})

});