FactoryGirl.define do
  factory :user do
    name "MyString"
    email "MyString"
    password ""
    description "MyText"
  end
end
