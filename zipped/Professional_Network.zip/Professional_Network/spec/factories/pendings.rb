FactoryGirl.define do
  factory :pending do
    user nil
    inviter nil
  end
end
