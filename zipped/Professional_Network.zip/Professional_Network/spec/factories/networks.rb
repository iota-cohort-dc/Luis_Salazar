FactoryGirl.define do
  factory :network do
    user nil
    friend nil
  end
end
