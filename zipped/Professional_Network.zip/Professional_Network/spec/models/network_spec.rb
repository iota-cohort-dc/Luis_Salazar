require 'rails_helper'

RSpec.describe Network, type: :model do
  pending "add some examples to (or delete) #{__FILE__}"
end
