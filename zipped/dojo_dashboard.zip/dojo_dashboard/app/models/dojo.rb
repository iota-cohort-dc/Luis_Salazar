class Dojo < ApplicationRecord
end
