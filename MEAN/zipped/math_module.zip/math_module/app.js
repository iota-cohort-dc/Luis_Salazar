var my_module = require('./mathlib')();
my_module.add(2,3);
my_module.multiply(2,3);
my_module.square(5);
my_module.random(2,100);