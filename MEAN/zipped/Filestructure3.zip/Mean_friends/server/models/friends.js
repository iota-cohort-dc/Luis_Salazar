var mongoose = require('mongoose');
var FriendSchema = new mongoose.Schema({
	


},{timestamps:true});
var Friends = mongoose.model('Friends',FriendSchema);