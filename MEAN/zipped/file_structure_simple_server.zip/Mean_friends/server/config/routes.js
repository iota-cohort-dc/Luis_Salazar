module.exports = function(app) {
	console.log('future routes.');

}