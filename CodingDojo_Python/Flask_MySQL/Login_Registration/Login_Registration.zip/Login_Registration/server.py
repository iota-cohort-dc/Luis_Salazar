from flask import Flask, request, redirect, render_template,session, flash
from mysqlconnection import MySQLConnector
from flask.ext.bcrypt import Bcrypt
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

app = Flask(__name__)
bcrypt = Bcrypt(app)
mysql = MySQLConnector(app,'loginDb')
app.secret_key = 'thisiSecret'

@app.route('/', methods=['GET'])
def index():
	

	return render_template('index.html')

@app.route('/success', methods=['POST'])
def success():
	
	if not EMAIL_REGEX.match(request.form['email']):
		flash('INVALID EMAIL')
		return redirect('/')
	if len(request.form['password'])<1:
		flash('Must enter a password')
		return redirect('/')
	else:
		email = request.form['email']
		password = request.form['password']
	
		user_query = "SELECT * FROM users WHERE email = :email LIMIT 1"
		query_data = { 'email': email }
	
		user = mysql.query_db(user_query, query_data) # user will be returned in a list
	
	if bcrypt.check_password_hash(user[0]['pw_hash'], password):
		flash("Welcome! " + str(user[0]['first_name']) + " " + str(user[0]['last_name']))
		
		table = 'SELECT first_name FROM users'
		info = mysql.query_db(table)
		return render_template('success.html', all_info=info)

	else:
		flash('Sorry could not verify Email or Password. Please try again')
		return redirect('/')


		

@app.route('/create', methods=['POST'])
def create():
	
	if len(request.form['fname']) < 2:
		flash('First name needs to be greater that 2 characters')
		return redirect('/')
	if len(request.form['lname']) <2:
		flash('Last name needs to be greater that 2 characters')
		return redirect('/')
	if not EMAIL_REGEX.match(request.form['email']):
		flash('INVALID EMAIL')
		return redirect('/')
	if len(request.form['pass']) <= 7:
		flash('Password must be atleast 8 characters')
		return redirect('/')
	if request.form['pass'] != request.form['conpass']:
		flash ('Passwords do NOT match. please try again.')
		return redirect('/')

	else:
		first_name = request.form['fname']
		last_name = request.form['lname']
		email = request.form['email']
		password = request.form['pass']

		pw_hash = bcrypt.generate_password_hash(password)
		insert_query = "INSERT INTO users (first_name, last_name, pw_hash, email) VALUES (:first_name, :last_name, :pw_hash, :email)"
		query_data = { 'first_name': first_name, 'last_name': last_name, 'pw_hash': pw_hash, 'email': email }
		mysql.query_db(insert_query, query_data)
		flash('Success! Thank you for registering')
		return render_template ('success.html')












app.run(debug=True)