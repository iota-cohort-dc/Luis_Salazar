Ideas for New Command Extensions
================================

:synopsis: Here are some ideas for some future command extensions.

* create form/manager for App
* CSS and JS concatenation and minification scripts
