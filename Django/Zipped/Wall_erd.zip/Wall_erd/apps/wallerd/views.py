from django.shortcuts import render
from models import Users,Messages,Comments

# Create your views here.
def index(request):
	Users.objects.create(first_name='Luis', last_name='Saladbar', email = 'luis@gmail.com', password = 'poop')
	users = Users.objects.all()
	print users
	return render(request, 'wallerd/index.html')
	