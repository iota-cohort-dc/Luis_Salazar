from __future__ import unicode_literals

from django.db import models
from ..login_app.models import Users

# Create your models here.

class Trips(models.Model):
	destination = models.CharField(max_length=255)
	description = models.TextField()
	date_from = models.DateTimeField(null=True, blank=True)
	date_to = models.DateTimeField(null=True, blank=True)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

class CombineTrip(models.Model):
	trip = models.ForeignKey(Trips, related_name='all_trips')
	user = models.ForeignKey(Users, related_name='all_users')
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
