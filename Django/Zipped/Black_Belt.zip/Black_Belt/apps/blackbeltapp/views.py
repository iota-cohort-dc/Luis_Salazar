from django.shortcuts import render,redirect
from . models import Trips, CombineTrip, Users
from django.core.urlresolvers import reverse


# Create your views here.
def index(request):
	context = {
	'user': Users.objects.get(id=request.session['log_user_id']),
	'trip': Trips.objects.all(),
	}
	

	return render(request,'blackbeltapp/index.html',context)

def destination(request,id):
	context = {
	'dest': Trips.objects.get(id=id),
	# 'user': Users.objects.get(id=id),
	}
	

	return render(request,'blackbeltapp/destination.html',context)

def add(request):

	return render(request, 'blackbeltapp/add.html')

def create(request):
	trip = Trips.objects.create(destination=request.POST['destin'], description=request.POST['plan'], date_from=request.POST['from'], date_to=request.POST['to'])

	return redirect(reverse('blackbelt:index'))

